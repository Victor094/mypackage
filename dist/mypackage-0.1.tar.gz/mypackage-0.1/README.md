#mypackage
This library was create as an example of how to publish you own python packages

## building this package locally
'python setup.py sdist'

## installing this package from github
'pip install git +'

## update this package from github
'pip install --upgraye git+'
